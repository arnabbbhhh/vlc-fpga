----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.03.2026 15:04:19
-- Design Name: 
-- Module Name: vga - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity vga is
 Port ( clk       : in  std_logic;              -- 25 MHz pixel clock 
        hsync     : out std_logic;
          vsync     : out std_logic;
          video_on  : out std_logic;
          hcount    : out integer range 0 to 799;
         vcount    : out integer range 0 to 524
  );
end vga;

architecture Behavioral of vga is
signal hc : integer range 0 to 799 := 0;
  signal vc : integer range 0 to 524 := 0;
begin
  -- horizontal / vertical counters
  process(clk)
  begin
   if rising_edge(clk) then
         if hc = 799 then
         hc <= 0;
           if vc = 524 then
                 vc <= 0;
           else
                 vc <= vc + 1;
           end if;
           else
           hc <= hc + 1;
           end if;
           end if;
           end process;
               -- sync pulses (640x480@60Hz standard)
           hsync    <= '0' when (hc >= 656 and hc < 752) else '1';
           vsync    <= '0' when (vc >= 490 and vc < 492) else '1';
           video_on <= '1' when (hc < 640 and vc < 480) else '0';
           hcount   <= hc;    vcount   <= vc;
  



end Behavioral;
