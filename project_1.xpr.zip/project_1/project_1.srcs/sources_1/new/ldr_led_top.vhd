library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ldr_led_top is
    Port (
        ldr_in  : in  STD_LOGIC;   -- from LDR voltage divider
        led_out : out STD_LOGIC    -- to Zybo LED
    );
end ldr_led_top;

architecture Behavioral of ldr_led_top is
begin

    -- Light => ldr_in = '1' => LED ON
    -- Dark  => ldr_in = '0' => LED OFF
    led_out <= ldr_in;

end Behavioral;
